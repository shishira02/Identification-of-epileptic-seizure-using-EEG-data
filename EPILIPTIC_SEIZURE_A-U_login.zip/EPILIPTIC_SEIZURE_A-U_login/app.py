from flask import Flask, render_template, request, session
import csv
import sqlite3
from epileptic_seizure import Traning, Testing
import pandas as pd
import os

connection = sqlite3.connect('user_data.db')
cursor = connection.cursor()

command = """CREATE TABLE IF NOT EXISTS user(name TEXT, password TEXT, mobile TEXT, email TEXT)"""
cursor.execute(command)

command = """CREATE TABLE IF NOT EXISTS admin(name TEXT, password TEXT, mobile TEXT, email TEXT)"""
cursor.execute(command)

app = Flask(__name__)
app.secret_key = os.urandom(12)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/home')
def home():
    f = open('session.txt', 'r')
    result = f.read()
    f.close()
    print(result)
    result=result.split(',')
    name, password, phone, email = result
    return render_template('log.html', name=name, phone=phone, email=email, password=password)

@app.route('/graphpage')
def graphpage():
    return render_template('graph.html')

@app.route('/userlog', methods=['GET', 'POST'])
def userlog():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']

        query = "SELECT name, password, mobile, email FROM user WHERE name = '"+name+"' AND password= '"+password+"'"
        cursor.execute(query)

        result = cursor.fetchone()

        if result:
            name, password, phone, email = result
            f = open('session.txt', 'w')
            f.write(name+','+password+','+phone+','+email)
            f.close()
            session['Type'] = 'user'
            return render_template('log.html', name=name, phone=phone, email=email, password=password)
            
        else:
            return render_template('index.html', msg='Sorry, Incorrect Credentials Provided,  Try Again')
            

    return render_template('index.html')


@app.route('/userreg', methods=['GET', 'POST'])
def userreg():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']
        mobile = request.form['phone']
        email = request.form['email']
        
        print(name, mobile, email, password)


        cursor.execute("INSERT INTO user VALUES ('"+name+"', '"+password+"', '"+mobile+"', '"+email+"')")
        connection.commit()

        return render_template('index.html', msg='Successfully Registered')
    
    return render_template('index.html')




@app.route('/adminlog', methods=['GET', 'POST'])
def adminlog():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']

        query = "SELECT name, password, mobile, email FROM user WHERE name = '"+name+"' AND password= '"+password+"'"
        cursor.execute(query)

        result = cursor.fetchone()

        if result:
            name, password, phone, email = result
            f = open('session.txt', 'w')
            f.write(name+','+password+','+phone+','+email)
            f.close()
            session['Type'] = 'admin'
            return render_template('adminlog.html', name=name, phone=phone, email=email, password=password)
            
        else:
            return render_template('index.html', msg='Sorry, Incorrect Credentials Provided,  Try Again')
             

    return render_template('index.html')


@app.route('/adminreg', methods=['GET', 'POST'])
def adminreg():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']
        mobile = request.form['phone']
        email = request.form['email']
        
        print(name, mobile, email, password)


        cursor.execute("INSERT INTO user VALUES ('"+name+"', '"+password+"', '"+mobile+"', '"+email+"')")
        connection.commit()

        return render_template('index.html', msg='Successfully Registered')
    
    return render_template('index.html')
@app.route('/traindata', methods=['GET', 'POST'])
def traindata():
    if request.method == 'POST':
        file1 = request.form['file1']
        print(file1)
        result = []
        f = open(file1, 'r')
        Data = csv.reader(f)
        for row in Data:
            result.append(row) 
        f.close()   
        return render_template('admintrainpage.html',  train_result=result, file1=file1)

    return render_template('admintrainpage.html')

@app.route('/testdata', methods=['GET', 'POST'])
def testdata():
    if request.method == 'POST':
        file1 = request.form['file1']
        print(file1)

        result = []
        f = open(file1, 'r')
        Data = csv.reader(f)
        for row in Data:
            result.append(row) 
        f.close()   
        if session['Type'] ==  'user':
            return render_template('testpage.html',  test_result=result, file1=file1)
        else:
            return render_template('admintestpage.html',  test_result=result, file1=file1)

    return render_template('testpage.html')

@app.route('/training/<File>')
def training(File):
    print(File)
    model_names, acc = Traning(File)
    print(model_names, acc)
    f = open('model_select.txt', 'w')
    a = max(acc)
    model_name = model_names[acc.index(a)]
    f.write(model_name)
    f.close()
    return render_template('admintrainpage.html', info='Training completed', model_names=model_names, acc=acc)

@app.route('/testing/<File>')
def testing(File):
    print(File)
    Col = Testing(File)

    result = []
    f = open(File, 'r')
    Data = csv.reader(f)
    i = 0
    for row in Data:
        row.append(Col[i])
        if Col[i] == 0:
            row.append("Normal")
        if Col[i] == 1:
            row.append("Epileptic seizures")
        col_name=["X1","X2","X3","X4","X5","X6","X7","X8","X9","X10","X11","X12","X13","X14","X15","X16","X17","X18","X19","X20","X21","X22","X23","X24","X25","X26","X27","X28","X29","X30","X31","X32","X33","X34","X35","X36","X37","X38","X39","X40","X41","X42","X43","X44","X45","X46","X47","X48","X49","X50","X51","X52","X53","X54","X55","X56","X57","X58","X59","X60","X61","X62","X63","X64","X65","X66","X67","X68","X69","X70","X71","X72","X73","X74","X75","X76","X77","X78","X79","X80","X81","X82","X83","X84","X85","X86","X87","X88","X89","X90","X91","X92","X93","X94","X95","X96","X97","X98","X99","X100","X101","X102","X103","X104","X105","X106","X107","X108","X109","X110","X111","X112","X113","X114","X115","X116","X117","X118","X119","X120","X121","X122","X123","X124","X125","X126","X127","X128","X129","X130","X131","X132","X133","X134","X135","X136","X137","X138","X139","X140","X141","X142","X143","X144","X145","X146","X147","X148","X149","X150","X151","X152","X153","X154","X155","X156","X157","X158","X159","X160","X161","X162","X163","X164","X165","X166","X167","X168","X169","X170","X171","X172","X173","X174","X175","X176","X177","X178"]
        result.append(row) 
        i+=1
    
    import warnings
    warnings.filterwarnings('always')
    warnings.filterwarnings('ignore')
    import pandas as pd
    import matplotlib.pyplot as plt
    from matplotlib import style
    import missingno as msno
    import seaborn as sns

    i = 0
    for tcn in col_name:
        i += 1
        df=pd.read_csv(File, names=col_name)
        plt.figure(figsize=(20,10))
        sns.countplot(x=df[tcn],data=df,palette="twilight_shifted",saturation=2,dodge=True,)
        plt.savefig("static/graphs/"+tcn+".png")

    f1 = open('result.csv', 'w', newline="")
    writer = csv.writer(f1)
    writer.writerows(result)
    f1.close()

    f.close() 
    if session['Type'] ==  'user':
        return render_template('testpage.html', info1='Testing completed', test_output=result)
    else:
        return render_template('admintestpage.html', info1='Testing completed', test_output=result)

@app.route('/adminhome')
def adminhome():
    return render_template('adminlog.html')

@app.route('/testpage')
def testpage():
    return render_template('testpage.html')

@app.route('/admintrainpage')
def admintrainpage():
    return render_template('admintrainpage.html')

@app.route('/admintestpage')
def admintestpage():
    return render_template('admintestpage.html')

@app.route('/update_profile', methods=['GET', 'POST'])
def update_profile():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']
        mobile = request.form['phone']
        email = request.form['email']
        
        print(name, mobile, email, password)

        command = """CREATE TABLE IF NOT EXISTS user(name TEXT, password TEXT, mobile TEXT, email TEXT)"""
        cursor.execute(command)

        cursor.execute("INSERT INTO user VALUES ('"+name+"', '"+password+"', '"+mobile+"', '"+email+"')")
        connection.commit()

        return render_template('log.html', Alert='Successfully updated')
    return render_template('log.html')


@app.route('/update_adminprofile', methods=['GET', 'POST'])
def update_adminprofile():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']
        mobile = request.form['phone']
        email = request.form['email']
        
        print(name, mobile, email, password)

        command = """CREATE TABLE IF NOT EXISTS admin(name TEXT, password TEXT, mobile TEXT, email TEXT)"""
        cursor.execute(command)

        cursor.execute("INSERT INTO user VALUES ('"+name+"', '"+password+"', '"+mobile+"', '"+email+"')")
        connection.commit()

        return render_template('adminlog.html', Alert='Successfully updated')
    return render_template('adminlog.html')

@app.route('/generate_graph', methods=['GET', 'POST'])
def generate_graph():
    if request.method == 'POST':

        tcn = request.form['tcn']
        if not os.path.exists("static/graphs/"+tcn+".png"):
            if session['Type'] ==  'user':
                return render_template('graph.html', msg="graph not found")
            else:
                return render_template('admingraph.html', msg="graph not found")
        else:
            image = "http://127.0.0.1:5000/static/graphs/"+tcn+".png"
            if session['Type'] ==  'user':
                return render_template('graph.html', image=image, tcn=tcn)
            else:
                return render_template('admingraph.html', image=image, tcn=tcn)
    return render_template('index.html')

@app.route('/logout')
def logout():
    return render_template('index.html')

if __name__ == "__main__":
    for file in os.listdir('static/graphs'):
        os.remove('static/graphs/'+file)
    app.run(debug=True,use_reloader=False)
