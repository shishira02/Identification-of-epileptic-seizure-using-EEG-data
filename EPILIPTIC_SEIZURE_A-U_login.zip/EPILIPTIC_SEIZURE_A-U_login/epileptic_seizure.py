def Traning(File):
    import numpy as np
    import pandas as pd
    import matplotlib as plt
    import seaborn as sns
    from sklearn.metrics import classification_report
    from sklearn import metrics
    import pickle

    data=pd.read_csv(File)
    data.isnull().sum()
    d=pd.DataFrame(data.iloc[:,0:-1])
    d.head()

    from sklearn.preprocessing  import StandardScaler
    scaler=StandardScaler()
    scaled_data=scaler.fit_transform(d)
    X=scaled_data
    y=data['y']

    acc = []
    model = []

    from sklearn.model_selection import train_test_split
    Xtrain, Xtest, Ytrain, Ytest = train_test_split(X,y,test_size = 0.2,random_state =2)
    from sklearn.ensemble import RandomForestClassifier
    RF = RandomForestClassifier(n_estimators=100, random_state=42)
    RF.fit(Xtrain,Ytrain)
    predicted_values = RF.predict(Xtest)
    x = metrics.accuracy_score(Ytest, predicted_values)
    acc.append(x)
    model.append('RF')
    print("RF's Accuracy is: ", x)
    print(classification_report(Ytest,predicted_values))
    with open('rf.pkl', 'wb') as file:
        pickle.dump(RF,file)

    from sklearn.naive_bayes import GaussianNB
    NaiveBayes = GaussianNB()
    NaiveBayes.fit(Xtrain,Ytrain)
    predicted_values = NaiveBayes.predict(Xtest)
    x = metrics.accuracy_score(Ytest, predicted_values)
    acc.append(x)
    model.append('Naive Bayes')
    print("Naive Bayes's Accuracy is: ", x)
    print(classification_report(Ytest,predicted_values))
    with open('nb.pkl', 'wb') as file:
        pickle.dump(NaiveBayes,file)

    from sklearn.tree import DecisionTreeClassifier
    DecisionTree = DecisionTreeClassifier(criterion="entropy",random_state=2,max_depth=5)
    DecisionTree.fit(Xtrain,Ytrain)
    predicted_values = DecisionTree.predict(Xtest)
    x = metrics.accuracy_score(Ytest, predicted_values)
    acc.append(x)
    model.append('Decision Tree')
    print("DecisionTrees's Accuracy is: ", x*100)
    print(classification_report(Ytest,predicted_values))
    with open('dt.pkl', 'wb') as file:
        pickle.dump(DecisionTree,file)

    from sklearn.svm import SVC
    # data normalization with sklearn
    from sklearn.preprocessing import MinMaxScaler
    # fit scaler on training data
    norm = MinMaxScaler().fit(Xtrain)
    X_train_norm = norm.transform(Xtrain)
    # transform testing dataabs
    X_test_norm = norm.transform(Xtest)
    SVM = SVC(kernel='poly', degree=3, C=1)
    SVM.fit(X_train_norm,Ytrain)
    predicted_values = SVM.predict(X_test_norm)
    x = metrics.accuracy_score(Ytest, predicted_values)
    acc.append(x)
    model.append('SVM')
    print("SVM's Accuracy is: ", x)
    print(classification_report(Ytest,predicted_values))
    with open('svm.pkl', 'wb') as file:
        pickle.dump(SVM,file)

    return model, acc 

def Testing(File):
    import numpy as np
    import pandas as pd
    import csv
    import pickle
    Col = []
    models = {'RF':'rf.pkl', 
              'Naive Bayes':'nb.pkl', 
              'Decision Tree': 'dt.pkl', 
              'SVM': 'svm.pkl'}
    f = open('model_select.txt', 'r')
    Name = f.read()
    f.close()
    modelname = models[Name]
    model = pickle.load(open("rff.pkl","rb"))
    with open(File, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            features = row[:]
            prediction = model.predict([features])[0]
            Col.append(prediction)

    return Col
